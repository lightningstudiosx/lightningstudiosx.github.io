"""Compile Kaifish and plain Stockfish 19 to WebAssembly with identical flags (run prep.py first).

Four engines land in dist/:  kaifish-mt, kaifish-st, sf19-mt, sf19-st  (.js + .wasm each)
  -mt  pthreads + PROXY_TO_PTHREAD (needs SharedArrayBuffer, i.e. a cross-origin-isolated page)
  -st  no pthreads at all (KF_ST, fallback when the page is not cross-origin isolated)
Flags follow lichess-org/stockfish-web's sf_19 target (SSE4.1 via Emscripten's x86 SIMD layer on
top of -msimd128). The NNUE net is NOT embedded; the page hands it in at runtime.
Builds run at IDLE priority with 8 parallel jobs so they never slow a running engine match.
Usage: python -I build_wasm.py [kaifish|sf19 ...]
"""
import concurrent.futures as cf, glob, os, pathlib, shutil, subprocess, sys, time

WEB = pathlib.Path(__file__).resolve().parent
EMSDK = pathlib.Path(os.environ.get('EMSDK', r'C:\Users\aliev\emsdk'))
EMXX = str(EMSDK / 'upstream' / 'emscripten' / 'em++.exe')
ENV = {**os.environ, 'EMSDK': str(EMSDK), 'EM_CONFIG': str(EMSDK / '.emscripten')}
IDLE = 0x00000040
JOBS = 8

CXX = ['-O3', '-DNDEBUG', '-std=c++17', '-msimd128', '-mavx', '-flto', '-fno-exceptions',
       '-DUSE_POPCNT', '-DUSE_SSE2', '-DUSE_SSSE3', '-DUSE_SSE41', '-DNO_PREFETCH',
       '-DUSE_SLOPPY_ATOMICS', '-DNNUE_EMBEDDING_OFF', '-DNO_TABLEBASES', '-Wno-deprecated-declarations']
VARIANT = {'mt': ['-pthread'], 'st': ['-DKF_ST']}
LD = ['--pre-js', str(WEB / 'glue' / 'pre.js'), '--extern-post-js', str(WEB / 'glue' / 'post.js'),
      '-sMODULARIZE', '-sEXPORT_NAME=KFEngine', '-sENVIRONMENT=web,worker',
      "-sEXPORTED_FUNCTIONS=['_malloc','_main']",
      "-sEXPORTED_RUNTIME_METHODS=['stringToUTF8','lengthBytesUTF8','HEAPU8']",
      '-sINITIAL_MEMORY=64MB', '-sALLOW_MEMORY_GROWTH', '-sMAXIMUM_MEMORY=2GB']
LD_VARIANT = {'mt': ['-sPROXY_TO_PTHREAD', '-sSTACK_SIZE=3MB', '-Wno-pthreads-mem-growth'],
              'st': ['-sSTACK_SIZE=4MB']}


def run(cmd):
    r = subprocess.run(cmd, env=ENV, capture_output=True, text=True, creationflags=IDLE)
    if r.returncode:
        raise RuntimeError(' '.join(cmd[-3:]) + '\n' + r.stdout[-2000:] + r.stderr[-4000:])
    return r


def sources(src):
    return sorted(f for f in glob.glob('**/*.cpp', root_dir=src, recursive=True)
                  if not f.replace('\\', '/').startswith('universal/'))


def build(tree, variant, pool):
    src = WEB / 'work' / tree / 'src'
    obj = WEB / 'work' / f'obj-{tree}-{variant}'
    obj.mkdir(exist_ok=True)
    flags = CXX + VARIANT[variant] + ['-I' + str(src)]
    jobs = []
    for f in sources(src):
        o = obj / (f.replace('\\', '_').replace('/', '_')[:-4] + '.o')
        jobs.append((o, pool.submit(run, [EMXX, *flags, '-c', str(src / f), '-o', str(o)])))
    for _, j in jobs:
        j.result()
    out = WEB / 'dist' / f'{tree}-{variant}.js'
    out.parent.mkdir(exist_ok=True)
    run([EMXX, *flags, *LD, *LD_VARIANT[variant], *[str(o) for o, _ in jobs], '-o', str(out)])
    w = out.with_suffix('.wasm')
    print(f'  {out.name} {out.stat().st_size // 1024} KB, {w.name} {w.stat().st_size // 1024} KB', flush=True)


def main():
    trees = sys.argv[1:] or ['kaifish', 'sf19']
    t0 = time.time()
    with cf.ThreadPoolExecutor(JOBS) as pool:
        for tree in trees:
            for variant in ('mt', 'st'):
                print(f'building {tree}-{variant} ...', flush=True)
                build(tree, variant, pool)
    print(f'done in {time.time() - t0:.0f} s')


if __name__ == '__main__':
    main()
