"""Prepare the source trees for the Kaifish web (WebAssembly) and native comparison builds.

Never touches kaifish-src/, stockfish-src/, bin/, logs/ or tools/state/ (they are only read).
  work/kaifish        Kaifish with the tuned KF_* values baked in as constants, + web patches
  work/sf19           plain Stockfish 19, + the same web patches
  work/kaifish-native Kaifish baked, no web patches (for a native `bench` comparison)

Params: tools/state/quick_candidate.json if it exists, else tools/state/spsa_1.json "theta",
rounded with int(round(v)) exactly like tools/bake.py.
Usage: python -I prep.py
"""
import json, os, pathlib, re, shutil, subprocess

WEB = pathlib.Path(__file__).resolve().parent
ROOT = WEB.parent
WORK = WEB / 'work'
STATE = ROOT / 'tools' / 'state'
IGNORE = shutil.ignore_patterns('*.o', '*.d', '*.exe', '.git', '*.nnue', '*.gcda', '*.profdata')


def params():
    q = STATE / 'quick_candidate.json'
    if q.exists():
        p, src = json.loads(q.read_text()), 'quick_candidate.json'
    else:
        p, src = json.loads((STATE / 'spsa_1.json').read_text())['theta'], 'spsa_1.json theta'
    p = {k: int(round(v)) for k, v in p.items()}
    assert len(p) == 55, len(p)
    return p, src


def bake(tree, p):
    f = tree / 'src' / 'search.cpp'
    s = f.read_text()
    for n, v in p.items():
        s, k = re.subn(rf'^int {n} = -?\d+;$', f'constexpr int {n} = {v};', s, flags=re.M)
        assert k == 1, n
    s, k = re.subn(r'^TUNE\(.*\);$', '', s, flags=re.M)
    assert k == 1
    f.write_text(s, newline='\n')


def sub(f, old, new):
    s = f.read_text()
    assert s.count(old) == 1, (f.name, old[:60])
    f.write_text(s.replace(old, new), newline='\n')


def single_thread_edits(src):
    """KF_ST: no pthreads at all. Each Thread runs its jobs inline on the caller's stack, and the
    UCI loop drains the queued commands then returns (see glue/glue.cpp)."""
    t = src / 'thread.cpp'
    sub(t, '''    stdThread(
      create_native_thread(NativeThreadOptions{}.setLargeStack(true), &Thread::idle_loop, this)) {

    if (!stdThread.joinable())
    {
        std::cerr << "Failed to create search thread\\n";
        std::exit(EXIT_FAILURE);
    }
''', '''#ifndef KF_ST
    stdThread(
      create_native_thread(NativeThreadOptions{}.setLargeStack(true), &Thread::idle_loop, this)) {

    if (!stdThread.joinable())
    {
        std::cerr << "Failed to create search thread\\n";
        std::exit(EXIT_FAILURE);
    }
#else
    stdThread() {
    searching = false;
#endif
''')
    sub(t, '''    exit = true;
    start_searching();
    stdThread.join();''', '''    exit = true;
#ifndef KF_ST
    start_searching();
    stdThread.join();
#endif''')
    sub(t, '''void Thread::wait_for_search_finished() {
''', '''void Thread::wait_for_search_finished() {
#ifdef KF_ST
    return;
#endif
''')
    sub(t, '''void Thread::run_custom_job(std::function<void()> f) {
''', '''void Thread::run_custom_job(std::function<void()> f) {
#ifdef KF_ST
    f();
    return;
#endif
''')
    sub(src / 'uci.cpp', '        cmd = js_getline();\n', '''#ifdef KF_ST
        if (!js_trypop(cmd))
            return;
#else
        cmd = js_getline();
#endif
''')
    sub(src / 'uci.cpp', 'std::string js_getline();  // src/glue.cpp\n',
        'std::string js_getline();  // src/glue.cpp\nbool js_trypop(std::string&);\n')
    sub(src / 'main.cpp', '    uci_global->loop();\n', '#ifdef KF_ST\n    return 0;  // commands run from uci() in glue.cpp\n#endif\n    uci_global->loop();\n')
    sub(src / 'engine.cpp', '"Threads", Option(1, 1, MaxThreads,', '"Threads", Option(1, 1, KF_MAX_THREADS,')
    sub(src / 'engine.cpp', 'namespace Stockfish {\n', '''#ifdef KF_ST
    #define KF_MAX_THREADS 1
#else
    #define KF_MAX_THREADS MaxThreads
#endif

namespace Stockfish {
''')


def web_tree(src_tree, dst, p=None):
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src_tree, dst, ignore=IGNORE)
    if p:
        bake(dst, p)
    subprocess.run(['git', 'apply', '--whitespace=nowarn', str(WEB / 'patches' / 'stockfish-web-sf19.patch')],
                   cwd=dst, check=True, env={**os.environ, 'GIT_CEILING_DIRECTORIES': str(WORK)})  # not inside a repo
    single_thread_edits(dst / 'src')
    for g in ('glue.cpp', 'glue.hpp'):
        shutil.copy(WEB / 'glue' / g, dst / 'src' / g)


def main():
    p, src = params()
    WORK.mkdir(exist_ok=True)
    web_tree(ROOT / 'kaifish-src', WORK / 'kaifish', p)
    web_tree(ROOT / 'stockfish-src', WORK / 'sf19')
    nat = WORK / 'kaifish-native'
    if nat.exists():
        shutil.rmtree(nat)
    shutil.copytree(ROOT / 'kaifish-src', nat, ignore=IGNORE)
    bake(nat, p)
    shutil.copy(ROOT / 'stockfish-src' / 'src' / 'nn-1a298aa575a0.nnue', nat / 'src')
    (WORK / 'params.json').write_text(json.dumps({'source': src, 'params': p}, indent=1))
    print('prepared work/kaifish, work/sf19, work/kaifish-native with params from', src)


if __name__ == '__main__':
    main()
