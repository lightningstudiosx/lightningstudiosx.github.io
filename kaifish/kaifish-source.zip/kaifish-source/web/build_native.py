"""Native build of the *baked* Kaifish (work/kaifish-native, made by prep.py) for a `bench` comparison
with the WebAssembly build. Output goes to web/native/, never to bin/. Runs at IDLE priority, make -j8.
Usage: python -I build_native.py      (then: python -I build_native.py bench)
"""
import json, os, pathlib, re, shutil, subprocess, sys

WEB = pathlib.Path(__file__).resolve().parent
SRC = WEB / 'work' / 'kaifish-native' / 'src'
OUT = WEB / 'native'
BASH = r'C:\msys64\usr\bin\bash.exe'
ENV = {**os.environ, 'MSYSTEM': 'UCRT64'}
IDLE = 0x00000040


def sh(cmd, cwd):
    d = pathlib.Path(cwd).as_posix()
    return subprocess.run([BASH, '-lc', f"cd '{d}' && {cmd}"], env=ENV, capture_output=True, text=True,
                          creationflags=IDLE)


def bench(exe):
    r = sh(f"./{exe.name} bench 2>&1", exe.parent)
    m = re.search(r'Nodes searched\s*:\s*(\d+)', r.stdout)
    return int(m.group(1)) if m else None


def main():
    OUT.mkdir(exist_ok=True)
    if sys.argv[1:] == ['bench']:
        n = bench(OUT / 'kaifish-baked.exe')
        (OUT / 'bench.json').write_text(json.dumps({'kaifish': n}))
        print('Kaifish (baked, native) bench:', n)
        return
    r = sh('make -j8 build ARCH=x86-64-avx2 COMP=mingw', SRC)
    exe = SRC / 'stockfish.exe'
    if not exe.exists():
        sys.exit(r.stdout[-3000:] + r.stderr[-3000:])
    shutil.copy(exe, OUT / 'kaifish-baked.exe')
    for dll in ('libgcc_s_seh-1.dll', 'libstdc++-6.dll', 'libwinpthread-1.dll'):
        p = pathlib.Path(r'C:\msys64\ucrt64\bin') / dll
        if p.exists():
            shutil.copy(p, OUT / dll)
    n = bench(OUT / 'kaifish-baked.exe')
    (OUT / 'bench.json').write_text(json.dumps({'kaifish': n}))
    print('built native/kaifish-baked.exe; bench:', n)


if __name__ == '__main__':
    main()
