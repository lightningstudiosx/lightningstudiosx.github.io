// Kaifish web glue (--pre-js) - adapted from lichess-org/stockfish-web src/initModule.js (GPL-3.0).
if (!Module['listen']) Module['listen'] = (s) => console.log(s);
if (!Module['onError']) Module['onError'] = (s) => console.error(s);

function kfViews() {
  if (typeof growMemViews === 'function') growMemViews();
  else if (typeof updateMemoryViews === 'function') updateMemoryViews();
}

/** Copy the whole .nnue file into the wasm heap; the engine frees it after loading. */
Module['setNnueBuffer'] = function (buf) {
  const p = _malloc(buf.byteLength);
  if (!p) throw new Error('could not allocate ' + buf.byteLength + ' bytes for the net');
  kfViews();
  HEAPU8.set(buf, p);
  _setNnueBuffer(p, buf.byteLength);
};

/** Send one UCI line (freed in glue.cpp). */
Module['uci'] = function (cmd) {
  const n = lengthBytesUTF8(cmd) + 1;
  const p = _malloc(n);
  if (!p) throw new Error('could not allocate ' + n + ' bytes');
  kfViews();
  stringToUTF8(cmd, p, n);
  _uci(p);
};

Module['threaded'] = () => !!_kfThreaded();
Module['print'] = (s) => Module['listen'](s);
Module['printErr'] = (s) => Module['onError'](s);
