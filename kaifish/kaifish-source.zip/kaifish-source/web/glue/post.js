// Kaifish web glue (--extern-post-js): turns this engine script into a dedicated Worker that
// speaks UCI over postMessage.  page -> worker: {t:'net', buf} | {t:'uci', s}
//                                worker -> page: {t:'ready', threaded} | {t:'line', s} | {t:'err', s}
// Emscripten's own pthread workers load this same file (named 'em-pthread...') and skip this block.
(function () {
  if (typeof WorkerGlobalScope === 'undefined' || !(self instanceof WorkerGlobalScope)) return;
  if (String(self.name || '').indexOf('em-pthread') === 0) return;
  const here = self.location.href;
  const wasm = here.replace(/\.js(\?.*)?$/, '.wasm');
  let mod = null, backlog = [];
  const handle = (d) => {
    try {
      if (d.t === 'net') mod.setNnueBuffer(new Uint8Array(d.buf));
      else if (d.t === 'uci') mod.uci(String(d.s));
    } catch (e) { postMessage({ t: 'err', s: String(e && e.stack || e) }); }
  };
  self.onmessage = (e) => (mod ? handle(e.data) : backlog.push(e.data));
  KFEngine({
    mainScriptUrlOrBlob: here,
    locateFile: (p) => (p.endsWith('.wasm') ? wasm : new URL(p, here).href),
    listen: (s) => postMessage({ t: 'line', s }),
    onError: (s) => postMessage({ t: 'err', s }),
  }).then((m) => {
    mod = m;
    postMessage({ t: 'ready', threaded: m.threaded() });
    const b = backlog; backlog = [];
    b.forEach(handle);
  }, (e) => postMessage({ t: 'err', s: 'init failed: ' + e }));
})();
