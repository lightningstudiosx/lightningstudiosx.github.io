"""Headless-Chromium check of the four WebAssembly engines in dist/: uci / isready / go depth N / bench.
Serves dist/ plus the net over a local HTTP server that sends COOP/COEP (so the -mt builds get
SharedArrayBuffer), and compares each bench node count with the expected native signature.
Usage: python -I test_engines.py [kaifish-mt kaifish-st sf19-mt sf19-st]
"""
import functools, http.server, json, pathlib, re, sys, threading
from playwright.sync_api import sync_playwright

WEB = pathlib.Path(__file__).resolve().parent
NET = WEB.parent / 'stockfish-src' / 'src' / 'nn-1a298aa575a0.nnue'
SF19_BENCH = 2497913   # "Bench:" line of the Stockfish 19 release commit
sys.stdout.reconfigure(encoding='utf-8')
if sys.platform == 'win32':   # IDLE priority, inherited by Chromium: never slow a running engine match
    import ctypes
    ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)


class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        super().end_headers()

    def translate_path(self, path):
        return str(NET) if path.startswith('/net.nnue') else super().translate_path(path)

    def log_message(self, *a):
        pass


PAGE = """<!doctype html><meta charset=utf-8><title>t</title><script>
window.run = async (id, cmds) => {
  const net = await (await fetch('/net.nnue')).arrayBuffer();
  const w = new Worker('/' + id + '.js', {name: 'test'});
  const lines = []; let wake = null, threaded = null;
  w.onmessage = (e) => { const d = e.data; if (d.t === 'ready') threaded = d.threaded; if (d.t === 'line' || d.t === 'err') lines.push(d.s); if (wake) wake(); };
  const until = (re, ms) => new Promise((res, rej) => { const t0 = Date.now(); const chk = () => {
      const l = lines.find((x) => re.test(x)); if (l) { wake = null; res(l); } else if (Date.now() - t0 > ms) rej(new Error('timeout ' + re + ' last: ' + lines.slice(-5).join(' | ')));
      else { wake = chk; setTimeout(chk, 200); } }; chk(); });
  w.postMessage({t: 'net', buf: net}, [net]);
  const out = {};
  for (const [cmd, re, ms] of cmds) { lines.length = 0; const t0 = performance.now(); w.postMessage({t: 'uci', s: cmd});
    if (re) { out[cmd] = await until(new RegExp(re), ms); out[cmd + ' ms'] = Math.round(performance.now() - t0); out[cmd + ' all'] = lines.slice(); } }
  out.threaded = threaded; out.coi = self.crossOriginIsolated; w.terminate(); return out;
};
</script>"""


def main():
    ids = sys.argv[1:] or ['kaifish-mt', 'kaifish-st', 'sf19-mt', 'sf19-st']
    native = json.loads((WEB / 'native' / 'bench.json').read_text()) if (WEB / 'native' / 'bench.json').exists() else {}
    (WEB / 'dist' / 'test.html').write_text(PAGE, encoding='utf-8')
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(H, directory=str(WEB / 'dist')))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{srv.server_port}/test.html'
    fails, res = [], {}
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.on('console', lambda m: m.type == 'error' and fails.append('console: ' + m.text))
        pg.goto(url)
        for id in ids:
            cmds = [['uci', '^uciok$', 60000], ['isready', '^readyok$', 60000],
                    ['position startpos moves e2e4', None, 0], ['go depth 12', '^bestmove ', 120000],
                    ['bench', 'Nodes searched', 600000]]
            o = pg.evaluate('([id, c]) => run(id, c)', [id, cmds])
            name = next((l for l in o['uci all'] if l.startswith('id name')), '?')
            nodes = int(re.search(r'(\d+)', o['bench']).group(1))
            nps = next((l for l in o['bench all'] if 'Nodes/second' in l), '')
            want = SF19_BENCH if id.startswith('sf19') else native.get('kaifish')
            ok = want is None or nodes == want
            print(f"{id}: {name} | threaded={o['threaded']} coi={o['coi']} | go depth 12 -> {o['go depth 12']} "
                  f"({o['go depth 12 ms']} ms) | bench {nodes} {'== ' + str(want) if ok and want else ('!= ' + str(want) if want else '(no native ref)')} | {nps}", flush=True)
            res[id] = nodes
            if id.endswith('-mt'):   # do the extra threads really search? compare nps at 1 and 4 threads
                nps_at = {}
                for th in (1, 4):
                    q = pg.evaluate('([id, c]) => run(id, c)', [id, [['setoption name Threads value %d' % th, None, 0], ['isready', '^readyok$', 60000],
                                    ['position startpos', None, 0], ['go movetime 3000', '^bestmove ', 60000]]])
                    nps_at[th] = max(int(m.group(1)) for m in (re.search(r' nps (\d+)', l) for l in q['go movetime 3000 all']) if m)
                print(f'  {id}: nps 1 thread {nps_at[1]:,} -> 4 threads {nps_at[4]:,} ({nps_at[4] / nps_at[1]:.2f}x)', flush=True)
                if nps_at[4] < 1.5 * nps_at[1]:
                    fails.append(f'{id}: 4 threads not faster')
            if not ok:
                fails.append(f'{id} bench {nodes} != {want}')
        b.close()
    srv.shutdown()
    (WEB / 'dist' / 'test.html').unlink()
    bj = WEB / 'dist' / 'bench.json'
    bj.write_text(json.dumps({**(json.loads(bj.read_text()) if bj.exists() else {}), **res}, indent=1))
    if len({res.get('kaifish-mt'), res.get('kaifish-st')} - {None}) > 1 or len({res.get('sf19-mt'), res.get('sf19-st')} - {None}) > 1:
        fails.append('mt and st bench differ')
    if res.get('kaifish-mt') and res.get('kaifish-mt') == res.get('sf19-mt'):
        fails.append('Kaifish and SF19 bench are identical - tuned params not baked?')
    print('FAILURES:\n  ' + '\n  '.join(fails) if fails else 'all engine checks passed')


if __name__ == '__main__':
    main()
