// Kaifish web glue - adapted from lichess-org/stockfish-web src/glue.hpp (GPL-3.0).
// A queue of UCI lines / NNUE buffers handed in from JavaScript.
#pragma once

#include <emscripten.h>
#include <cstdlib>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <queue>
#include <streambuf>
#include <string>

struct Command: public std::streambuf {
    enum { UCI, NNUE } type = UCI;
    std::string           uci;
    std::shared_ptr<void> ptr = nullptr;

    Command() = default;
    Command(const char* text) : type(UCI), uci(text) { std::free((void*) text); }
    Command(char* buf, size_t sz) : type(NNUE), ptr((void*) buf, std::free) { setg(buf, buf, buf + sz); }
    Command(const Command& o) : std::streambuf(o), type(o.type), uci(o.uci), ptr(o.ptr) {}
    Command& operator=(const Command& o) {
        std::streambuf::operator=(o);
        type = o.type, uci = o.uci, ptr = o.ptr;
        return *this;
    }

    using std::streambuf::seekoff;
    using std::streambuf::seekpos;
};

struct CommandQueue {
    std::mutex              m;
    std::queue<Command>     q;
    std::condition_variable cv;

    void push(Command el) {
        std::unique_lock<std::mutex> lock(m);
        q.push(el);
        lock.unlock();
        cv.notify_one();
    }

    Command pop() {  // blocks (multi-threaded build: the UCI loop runs in its own pthread)
        std::unique_lock<std::mutex> lock(m);
        while (q.empty())
            cv.wait(lock);
        Command el = q.front();
        q.pop();
        return el;
    }

    bool try_pop(Command& out) {  // never blocks (single-threaded build)
        std::unique_lock<std::mutex> lock(m);
        if (q.empty())
            return false;
        out = q.front();
        q.pop();
        return true;
    }
};
