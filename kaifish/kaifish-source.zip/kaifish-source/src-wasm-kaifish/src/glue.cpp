// Kaifish web glue - adapted from lichess-org/stockfish-web src/glue.cpp (GPL-3.0).
// JavaScript calls uci("...") and setNnueBuffer(ptr, size); the engine's UCI loop reads them
// through js_getline() (pthread build, PROXY_TO_PTHREAD) or js_trypop() (KF_ST build, where
// each call drains the queue synchronously on the worker's own thread).
#include "glue.hpp"

#include <iostream>
#include <string>

#include "misc.h"
#include "uci.h"

extern Stockfish::UCIEngine* uci_global;

static CommandQueue inQ;

static std::string run(Command& cmd) {
    if (cmd.type == Command::UCI)
        return cmd.uci;
    if (cmd.ptr)
    {
        std::istream in(&cmd);
        uci_global->engine.load_big_network(in);
        std::cout << "info string kaifish-web nnue loaded" << std::endl;
    }
    return "";
}

std::string js_getline() {
    Command cmd = inQ.pop();
    return run(cmd);
}

bool js_trypop(std::string& out) {
    Command cmd;
    if (!inQ.try_pop(cmd))
        return false;
    out = run(cmd);
    return true;
}

static void drain() {
#ifdef KF_ST
    if (uci_global)
        uci_global->loop();
#endif
}

extern "C" {
EMSCRIPTEN_KEEPALIVE void uci(const char* utf8) {
    inQ.push(Command(utf8));
    drain();
}

EMSCRIPTEN_KEEPALIVE void setNnueBuffer(char* buf, size_t sz) {
    inQ.push(Command(buf, sz));
    drain();
}

EMSCRIPTEN_KEEPALIVE int kfThreaded() {
#ifdef KF_ST
    return 0;
#else
    return 1;
#endif
}
}
