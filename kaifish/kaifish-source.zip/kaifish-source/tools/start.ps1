# Starts (or resumes) the Kaifish loop as a detached process at below-normal priority.
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (Test-Path STOP) { Remove-Item STOP }
$py = (Get-Command python).Source
$cmd = "cmd /c `"`"$py`" tools\kaifish_run.py > logs\runner.out 2> logs\runner.err`""
# ShowWindow = 0: run with no visible console window, so it can't be closed by accident (stop it with stop.bat)
$si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }
$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd; CurrentDirectory = $root; ProcessStartupInformation = $si }
Start-Sleep 5
Get-CimInstance Win32_Process -Filter "ParentProcessId=$($r.ProcessId) AND Name='python.exe'" | ForEach-Object {
  $p = Get-Process -Id $_.ProcessId; $p.PriorityClass = 'BelowNormal'
  Set-Content logs\runner.pid $p.Id; "Kaifish loop started (pid $($p.Id))"
}
