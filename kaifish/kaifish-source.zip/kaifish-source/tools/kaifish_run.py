"""Kaifish month-long improvement loop.

Repeats forever (until a STOP file appears):
  1. SPSA-tune the 55 KF_* search parameters, starting from the current best, by playing
     game pairs between two slightly perturbed Kaifish copies (fishtest-style SPSA).
  2. SPRT-test the tuned values against the current best (short time control, then long).
  3. Only if BOTH tests pass is the tuned set accepted as the new best (saved in best.json).
Separately, every accepted best is measured against plain Stockfish 19 (vs_sf19.json).

Everything is resumable: state lives in tools/state/*.json, logs in logs/.
"""
import json, math, os, random, re, subprocess, sys, threading, time, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
BIN, ST, LOGS = ROOT / 'bin', ROOT / 'tools' / 'state', ROOT / 'logs'
ST.mkdir(parents=True, exist_ok=True); LOGS.mkdir(exist_ok=True)
FC, KF, SF = str(BIN / 'fastchess.exe'), str(BIN / 'kaifish-tune.exe'), str(BIN / 'stockfish19.exe')
BOOK = str(ROOT / 'books' / 'UHO_Lichess_4852_v1.epd')
CONC = int(os.environ.get('KF_CONC', '24'))          # total games at once (24 of 32 threads)
WORKERS, PER = CONC // 4, 4                          # SPSA: 6 workers x 4 games at once
PAIRS_PER_BATCH = 4                                  # game pairs per SPSA batch
QUICK = (ROOT / 'QUICK').exists()                    # quick mode: one short round, then a match vs Stockfish 19
SPSA_PAIRS = 20000 if QUICK else 60000               # game pairs per SPSA round
STC, LTC = '10+0.1', '40+0.4'
BELOW_NORMAL = 0x00004000
STOP = ROOT / 'STOP'


GAMES = ('GeometryDash.exe', 'Minecraft.Windows.exe', 'javaw.exe', 'RobloxPlayerBeta.exe',
         'RobloxStudioBeta.exe', 'FortniteClient-Win64-Shipping.exe')
_game_seen = [0.0, False]
_paused = [False]


def game_running():
    """True while one of the user's games is open (checked at most every 15 s). Kaifish then yields the CPU."""
    if (ROOT / 'NOPAUSE').exists():   # the user asked for Kaifish to keep running while games are open
        return False
    now = time.time()
    if now - _game_seen[0] > 15:
        try:
            out = subprocess.run(['tasklist', '/fo', 'csv', '/nh'], capture_output=True, text=True,
                                 creationflags=0x08000000).stdout.lower()
            _game_seen[1] = any(f'"{g.lower()}"' in out for g in GAMES)
        except Exception:
            _game_seen[1] = False
        _game_seen[0] = now
    return _game_seen[1]


def log(msg):
    line = time.strftime('%Y-%m-%d %H:%M:%S ') + msg
    print(line, flush=True)
    with open(LOGS / 'kaifish.log', 'a', encoding='utf-8') as f: f.write(line + '\n')


def jload(name, default):
    p = ST / name
    return json.loads(p.read_text()) if p.exists() else default


def jsave(name, obj):
    p = ST / name; tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj, indent=1)); os.replace(tmp, p)


def opts(values):
    return [f'option.{k}={int(round(v))}' for k, v in values.items()]


def fastchess(args, tag):
    """Run fastchess at below-normal priority; return its full output text."""
    cmd = [FC] + args + ['-openings', f'file={BOOK}', 'format=epd', 'order=random',
                         '-each', 'option.Hash=16', 'option.Threads=1', '-recover']
    with open(LOGS / f'{tag}.out', 'w', encoding='utf-8') as out:
        p = subprocess.run(cmd, cwd=BIN, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, creationflags=BELOW_NORMAL)
        out.write(p.stdout)
    return p.stdout


def wld(text):
    m = re.findall(r'Games: (\d+), Wins: (\d+), Losses: (\d+), Draws: (\d+)', text)
    return tuple(map(int, m[-1]))[1:] if m else (0, 0, 0)


# ---------------------------------------------------------------- SPSA
def spsa_round(rnd, start):
    meta = {p['name']: p for p in json.loads((ROOT / 'tools' / 'params_default.json').read_text())}
    S = jload(f'spsa_{rnd}.json', None)
    if S is None:
        S = {'k': 0, 'theta': dict(start), 'wins': 0, 'losses': 0, 'draws': 0, 'started': time.time()}
    N, A = SPSA_PAIRS, 0.1 * SPSA_PAIRS
    lock = threading.Lock()

    def worker(wid):
        while True:
            if wid == 0 and game_running() and not _paused[0]:
                _paused[0] = True; log('  a game is open - Kaifish is pausing until it closes')
            while game_running() and not STOP.exists():
                time.sleep(15)
            if wid == 0 and _paused[0]:
                _paused[0] = False; log('  game closed - Kaifish resuming')
            with lock:
                if S['k'] >= N or STOP.exists(): return
                k = S['k']; S['k'] += PAIRS_PER_BATCH
                plus, minus, flips, cks = {}, {}, {}, {}
                for n, p in meta.items():
                    c_end = (p['max'] - p['min']) / 20
                    ck = c_end * N ** 0.101 / (k + 1) ** 0.101
                    f = random.choice((-1, 1)); flips[n], cks[n] = f, ck
                    plus[n] = min(p['max'], max(p['min'], S['theta'][n] + ck * f))
                    minus[n] = min(p['max'], max(p['min'], S['theta'][n] - ck * f))
            out = fastchess(['-engine', f'cmd={KF}', 'name=plus', *opts(plus),
                             '-engine', f'cmd={KF}', 'name=minus', *opts(minus),
                             '-each', f'tc={STC}', '-games', '2', '-rounds', str(PAIRS_PER_BATCH),
                             '-repeat', '-concurrency', str(PER)], f'spsa_w{wid}')
            w, l, d = wld(out)
            with lock:
                res = w - l
                for n, p in meta.items():
                    c_end = (p['max'] - p['min']) / 20
                    a = 0.002 * c_end ** 2 * (A + N) ** 0.602
                    ak = a / (A + k + 1) ** 0.602
                    S['theta'][n] = min(p['max'], max(p['min'], S['theta'][n] + ak / cks[n] * res * flips[n]))
                S['wins'] += w; S['losses'] += l; S['draws'] += d
                jsave(f'spsa_{rnd}.json', S)

    log(f'SPSA round {rnd}: from pair {S["k"]} of {N}')
    ts = [threading.Thread(target=worker, args=(i,), daemon=True) for i in range(WORKERS)]
    for t in ts: t.start()
    last = 0
    while any(t.is_alive() for t in ts):
        time.sleep(30)
        if time.time() - last > 600:
            last = time.time(); log(f'  SPSA {rnd}: {S["k"]}/{N} pairs')
    jsave(f'spsa_{rnd}.json', S)
    return S['k'] >= N, {n: round(v) for n, v in S['theta'].items()}


# ---------------------------------------------------------------- SPRT
def sprt(cand, base, tc, e0, e1, tag, base_cmd=None, maxgames=200000):
    base_engine = ['-engine', f'cmd={base_cmd}', 'name=base'] if base_cmd else \
                  ['-engine', f'cmd={KF}', 'name=base', *opts(base)]
    out = fastchess(['-engine', f'cmd={KF}', 'name=cand', *opts(cand), *base_engine,
                     '-each', f'tc={tc}', '-games', '2', '-rounds', str(maxgames // 2), '-repeat',
                     '-concurrency', str(CONC), '-sprt', f'elo0={e0}', f'elo1={e1}',
                     'alpha=0.05', 'beta=0.05', 'model=normalized', '-ratinginterval', '200'], tag)
    llr = re.findall(r'LLR: (-?[\d.]+) (?:\(-?[\d.]+%\) )?\((-?[\d.]+), (-?[\d.]+)\)', out)
    elo = re.findall(r'Elo: (-?[\d.]+) \+/- ([\d.]+)', out)
    w, l, d = wld(out)
    r = {'w': w, 'l': l, 'd': d, 'elo': elo[-1] if elo else None, 'llr': llr[-1] if llr else None}
    r['passed'] = bool(llr) and float(llr[-1][0]) >= float(llr[-1][2])
    return r


def elo_of(w, l, d):
    """Elo difference and 95% error from a W/L/D total (trinomial approximation)."""
    n = w + l + d
    if n == 0:
        return None
    s = min(max((w + d / 2) / n, 1e-6), 1 - 1e-6)
    var = (w * (1 - s) ** 2 + l * s ** 2 + d * (0.5 - s) ** 2) / n
    se = math.sqrt(var / n)
    e = lambda x: -400 * math.log10(1 / min(max(x, 1e-6), 1 - 1e-6) - 1)
    return [f'{e(s):.2f}', f'{(e(s + 1.96 * se) - e(s - 1.96 * se)) / 2:.2f}']


def measure_vs_sf19(best, tag, games=20000, chunk=500):
    """Fixed-length match vs real Stockfish 19 at STC: the honest headline number.
    Played in chunks of `chunk` games with the running total saved after each one, so closing
    the window or a restart only loses the chunk in progress."""
    P = jload(f'{tag}_partial.json', {'w': 0, 'l': 0, 'd': 0, 'chunks': 0})
    while P['w'] + P['l'] + P['d'] < games:
        if STOP.exists():
            raise SystemExit('STOP file found')
        while game_running():
            time.sleep(15)
        out = fastchess(['-engine', f'cmd={KF}', 'name=Kaifish', *opts(best),
                         '-engine', f'cmd={SF}', 'name=SF19', '-each', f'tc={STC}',
                         '-games', '2', '-rounds', str(chunk // 2), '-repeat', '-concurrency', str(CONC)],
                        f'{tag}_c{P["chunks"]}')
        w, l, d = wld(out)
        if w + l + d == 0:
            log('  vs SF19 chunk produced no games, retrying in 60 s'); time.sleep(60); continue
        P['w'] += w; P['l'] += l; P['d'] += d; P['chunks'] += 1
        jsave(f'{tag}_partial.json', P)
        el = elo_of(P['w'], P['l'], P['d'])
        log(f'  vs SF19: {P["w"] + P["l"] + P["d"]}/{games} games  +{P["w"]} -{P["l"]} ={P["d"]}  '
            f'Elo {el[0]} +/- {el[1]}')
    return {'w': P['w'], 'l': P['l'], 'd': P['d'], 'elo': elo_of(P['w'], P['l'], P['d']),
            'when': time.strftime('%Y-%m-%d %H:%M')}


# ---------------------------------------------------------------- main loop
def keep_awake():
    """Ask Windows not to sleep while this process runs (released automatically when it exits)."""
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000002)  # ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    except Exception:
        pass


def main():
    keep_awake()
    defaults = {p['name']: p['value'] for p in json.loads((ROOT / 'tools' / 'params_default.json').read_text())}
    best = jload('best.json', {'round': 0, 'params': defaults, 'history': []})
    run = jload('run.json', {'round': 1, 'stage': 'spsa'})
    log(f'Kaifish loop starting: round {run["round"]}, stage {run["stage"]}, concurrency {CONC}')
    while not STOP.exists():
        rnd = run['round']
        if run['stage'] == 'spsa':
            done, cand = spsa_round(rnd, best['params'])
            if not done: break
            run.update(stage='quicktest' if QUICK else 'stc', cand=cand); jsave('run.json', run)
        if run['stage'] == 'quicktest':
            log(f'Round {rnd} (quick): tuned Kaifish vs Stockfish 19, 10,000 games at {STC}')
            m = measure_vs_sf19(run['cand'], f'quick_vs_sf19_{rnd}', games=10000)
            if STOP.exists(): break
            hist = jload('vs_sf19.json', []); hist.append({'round': rnd, 'quick': True, **m}); jsave('vs_sf19.json', hist)
            log(f'  vs Stockfish 19: {m}')
            jsave('quick_candidate.json', run['cand'])
            run['stage'] = 'quickdone'; jsave('run.json', run)
        if run['stage'] == 'quickdone':
            log('Quick mode finished - stopping.'); break
        if run['stage'] == 'stc':
            log(f'Round {rnd}: SPRT short time control {STC} vs current best')
            r = sprt(run['cand'], best['params'], STC, 0, 2, f'sprt_stc_{rnd}')
            if STOP.exists(): break
            log(f'  STC result: {r}')
            run['stc'] = r
            run['stage'] = 'ltc' if r['passed'] else 'next'; jsave('run.json', run)
        if run['stage'] == 'ltc':
            log(f'Round {rnd}: SPRT long time control {LTC} vs current best')
            r = sprt(run['cand'], best['params'], LTC, 0.5, 2.5, f'sprt_ltc_{rnd}')
            if STOP.exists(): break
            log(f'  LTC result: {r}')
            run['ltc'] = r
            if r['passed']:
                best['params'] = run['cand']; best['round'] = rnd
                best['history'].append({'round': rnd, 'stc': run['stc'], 'ltc': r, 'when': time.strftime('%Y-%m-%d %H:%M')})
                jsave('best.json', best); log(f'  ACCEPTED: round {rnd} is the new Kaifish best')
                run['stage'] = 'measure'
            else:
                run['stage'] = 'next'
            jsave('run.json', run)
        if run['stage'] == 'measure':
            log(f'Round {rnd}: measuring new best vs Stockfish 19 (20,000 games)')
            m = measure_vs_sf19(best['params'], f'vs_sf19_{rnd}')
            if STOP.exists(): break
            hist = jload('vs_sf19.json', []); hist.append({'round': rnd, **m}); jsave('vs_sf19.json', hist)
            log(f'  vs Stockfish 19: {m}')
            run['stage'] = 'next'; jsave('run.json', run)
        if run['stage'] == 'next':
            run = {'round': rnd + 1, 'stage': 'spsa'}; jsave('run.json', run)
    log('Kaifish loop paused (STOP file present)' if STOP.exists() else 'Kaifish loop exited')


if __name__ == '__main__':
    main()
