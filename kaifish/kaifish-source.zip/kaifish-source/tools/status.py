"""Print where the Kaifish loop is and every result so far."""
import json, pathlib, time
R = pathlib.Path(__file__).resolve().parent.parent; S = R / 'tools' / 'state'
j = lambda n, d=None: json.loads((S / n).read_text()) if (S / n).exists() else d
run, best, vs = j('run.json', {}), j('best.json'), j('vs_sf19.json', [])
print('KAIFISH STATUS ', time.strftime('%Y-%m-%d %H:%M'))
print('paused (STOP file present)' if (R / 'STOP').exists() else 'running (if start.bat was used)')
print('round', run.get('round', 1), 'stage', run.get('stage', 'spsa'))
sp = j(f"spsa_{run.get('round', 1)}.json")
if sp: print(f"  SPSA: {sp['k']} / {20000 if (R / 'QUICK').exists() else 60000} game pairs   (+{sp['wins']} -{sp['losses']} ={sp['draws']})")
for k in ('stc', 'ltc'):
    if k in run: print(f'  {k.upper()} SPRT: {run[k]}')
print('accepted improvements:', len(best['history']) if best else 0)
for h in (best or {}).get('history', []): print('  round', h['round'], h['when'], 'STC', h['stc']['elo'], 'LTC', h['ltc']['elo'])
print('vs Stockfish 19 (Elo, +/-):')
for m in vs: print('  round', m['round'], m['when'], m['elo'], f"+{m['w']} -{m['l']} ={m['d']}")
if not vs: print('  no accepted version yet - Kaifish currently equals Stockfish 19')
tail = (R / 'logs' / 'kaifish.log').read_text().splitlines()[-5:] if (R / 'logs' / 'kaifish.log').exists() else []
print('\nlast log lines:'); print('\n'.join(tail))
