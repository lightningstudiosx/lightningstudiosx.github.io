"""Turn chosen search constants in search.cpp into tunable ints (exposed as UCI options via TUNE).
Each entry: (exact old text, new text with {names}, [(name, default)]).  Every old text must occur exactly once."""
import re, sys, json, pathlib
SRC = pathlib.Path(sys.argv[1]) / 'src' / 'search.cpp'
P = [
 ("alpha - 482 * depth * depth", "alpha - KF_razor * depth * depth", [("KF_razor", 482)]),
 ("(2789 * improving + 335 * opponentWorsening)", "(KF_futImp * improving + KF_futOpp * opponentWorsening)", [("KF_futImp", 2789), ("KF_futOpp", 335)]),
 ("(661 * beta + 363 * eval) / 1024", "(KF_futRb * beta + KF_futRe * eval) / 1024", [("KF_futRb", 661), ("KF_futRe", 363)]),
 ("beta - 13 * depth - 47 * improving + 365", "beta - KF_nmpD * depth - KF_nmpI * improving + KF_nmpC", [("KF_nmpD", 13), ("KF_nmpI", 47), ("KF_nmpC", 365)]),
 ("probCutBeta = beta + 241 - 64 * improving", "probCutBeta = beta + KF_pcB - KF_pcI * improving", [("KF_pcB", 241), ("KF_pcI", 64)]),
 ("probCutBeta = beta + 428", "probCutBeta = beta + KF_pcSmall", [("KF_pcSmall", 428)]),
 ("r += 929;", "r += KF_r1;", [("KF_r1", 929)]),
 ("ss->staticEval + 234 + 247 * lmrDepth", "ss->staticEval + KF_cfC + KF_cfD * lmrDepth", [("KF_cfC", 234), ("KF_cfD", 247)]),
 ("134 * captHist / 1024", "KF_cfH * captHist / 1024", [("KF_cfH", 134)]),
 ("int margin = 177 * depth", "int margin = KF_seeC * depth", [("KF_seeC", 177)]),
 ("history < -4136 * depth", "history < -KF_histPr * depth", [("KF_histPr", 4136)]),
 ("ss->staticEval + 119 * lmrDepth + 90 * (ss->staticEval > alpha) + 164", "ss->staticEval + KF_qfD * lmrDepth + KF_qfA * (ss->staticEval > alpha) + KF_qfC", [("KF_qfD", 119), ("KF_qfA", 90), ("KF_qfC", 164)]),
 ("r -= 3023 + PvNode * 1004 + (ttData.value > alpha) * 885", "r -= KF_r2 + PvNode * KF_r3 + (ttData.value > alpha) * KF_r4", [("KF_r2", 3023), ("KF_r3", 1004), ("KF_r4", 885)]),
 ("(816 + cutNode * 940)", "(KF_r5 + cutNode * KF_r6)", [("KF_r5", 816), ("KF_r6", 940)]),
 ("r += 697;", "r += KF_r7;", [("KF_r7", 697)]),
 ("r += 4026 + 933 * !ttData.move", "r += KF_r8 + KF_r9 * !ttData.move", [("KF_r8", 4026), ("KF_r9", 933)]),
 ("r += 1079;", "r += KF_r10;", [("KF_r10", 1079)]),
 ("r += 264 + 1095 * ((ss + 1)->cutoffCnt > 2) + 1138 * allNode", "r += KF_r11 + KF_r12 * ((ss + 1)->cutoffCnt > 2) + KF_r13 * allNode", [("KF_r11", 264), ("KF_r12", 1095), ("KF_r13", 1138)]),
 ("r -= 2179;", "r -= KF_r14;", [("KF_r14", 2179)]),
 ("r -= ss->statScore * 439 / 4096", "r -= ss->statScore * KF_r15 / 4096", [("KF_r15", 439)]),
 ("r += 1127;", "r += KF_r16;", [("KF_r16", 1127)]),
 ("futilityBase = ss->staticEval + 306", "futilityBase = ss->staticEval + KF_qsFut", [("KF_qsFut", 306)]),
 ("delta += 47 * delta / 128", "delta += KF_asp * delta / 128", [("KF_asp", 47)]),
 ("std::min(133 * depth - 81, 1487) + 364 * (bestMove == ttMove)", "std::min(KF_bnD * depth - KF_bnC, KF_bnM) + KF_bnTT * (bestMove == ttMove)", [("KF_bnD", 133), ("KF_bnC", 81), ("KF_bnM", 1487), ("KF_bnTT", 364)]),
 ("std::min(968 * depth - 235, 2244)", "std::min(KF_mlD * depth - KF_mlC, KF_mlM)", [("KF_mlD", 968), ("KF_mlC", 235), ("KF_mlM", 2244)]),
 ("int(2872 / 128.0 * std::log(i))", "int(KF_redLog / 128.0 * std::log(i))", [("KF_redLog", 2872)]),
 ("reductionScale - delta * 577 / rootDelta + !i * reductionScale * 197 / 512 + 982", "reductionScale - delta * KF_rdD / rootDelta + !i * reductionScale * KF_rdI / 512 + KF_rdC", [("KF_rdD", 577), ("KF_rdI", 197), ("KF_rdC", 982)]),
 ("int doubleMargin = -2 + 204 * PvNode - 152 * !ttCapture", "int doubleMargin = -2 + KF_dmP * PvNode - KF_dmC * !ttCapture", [("KF_dmP", 204), ("KF_dmC", 152)]),
 ("int tripleMargin = 70 + 279 * PvNode - 188 * !ttCapture", "int tripleMargin = KF_tmB + KF_tmP * PvNode - KF_tmC * !ttCapture", [("KF_tmB", 70), ("KF_tmP", 279), ("KF_tmC", 188)]),
 ("optimism[us]  = 114 * avg / (std::abs(avg) + 85)", "optimism[us]  = KF_opt1 * avg / (std::abs(avg) + KF_opt2)", [("KF_opt1", 114), ("KF_opt2", 85)]),
]
s = SRC.read_text()
params = []
for old, new, ps in P:
    n = s.count(old)
    if n != 1: sys.exit(f"expected 1 match, got {n}: {old}")
    s = s.replace(old, new); params += ps
decl = "\n// ---- Kaifish tunable search parameters (tuned by tools/spsa.py; defaults = Stockfish 19) ----\n"
decl += "".join(f"int {n} = {v};\n" for n, v in params)
decl += "TUNE(" + ", ".join(f"SetRange({max(0, v // 2 if v > 20 else 0)}, {v * 2 if v > 20 else v + 30}), {n}" for n, v in params) + ");\n"
s = s.replace('#include "ucioption.h"\n', '#include "ucioption.h"\n#include "tune.h"\n', 1)
s = s.replace("namespace Stockfish {\n", "namespace Stockfish {\n" + decl, 1)
SRC.write_text(s)
json.dump([{"name": n, "value": v, "min": max(0, v // 2 if v > 20 else 0), "max": v * 2 if v > 20 else v + 30} for n, v in params],
          open(pathlib.Path(sys.argv[1]).parent / 'tools' / 'params_default.json', 'w'), indent=1)
print(len(params), "params")
