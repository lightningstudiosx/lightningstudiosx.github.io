"""Build the release Kaifish: bake the best KF_* values (tools/state/best.json, else Stockfish 19 defaults)
into the source as constants, drop the tuning options, compile with PGO and copy to bin/kaifish.exe."""
import json, pathlib, re, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / 'kaifish-src' / 'src'
best_p = ROOT / 'tools' / 'state' / 'best.json'
params = json.loads(best_p.read_text())['params'] if best_p.exists() else \
    {p['name']: p['value'] for p in json.loads((ROOT / 'tools' / 'params_default.json').read_text())}

build = ROOT / 'build-release'
if build.exists(): shutil.rmtree(build)
shutil.copytree(ROOT / 'kaifish-src', build, ignore=shutil.ignore_patterns('*.o', '*.exe', '.git'))
s = (build / 'src' / 'search.cpp').read_text()
for n, v in params.items():
    s, k = re.subn(rf'^int {n} = -?\d+;$', f'constexpr int {n} = {int(round(v))};', s, flags=re.M)
    assert k == 1, n
s, k = re.subn(r'^TUNE\(.*\);$', '', s, flags=re.M); assert k == 1
(build / 'src' / 'search.cpp').write_text(s)
import os
src_dir = (build / 'src').as_posix()
r = subprocess.run([r'C:\msys64\usr\bin\bash.exe', '-lc', f"cd '{src_dir}' && make -j24 profile-build ARCH=native COMP=mingw"],
                   env={**os.environ, 'MSYSTEM': 'UCRT64'}, capture_output=True, text=True)
exe = build / 'src' / 'stockfish.exe'
if not exe.exists(): sys.exit(r.stdout[-3000:] + r.stderr[-3000:])
shutil.copy(exe, ROOT / 'bin' / 'kaifish.exe')
print('built bin/kaifish.exe with', 'best.json' if best_p.exists() else 'Stockfish 19 defaults')
