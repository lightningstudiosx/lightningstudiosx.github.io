KAIFISH 1 - complete corresponding source (GNU GPL v3, see Copying.txt)
Kaifish is Stockfish 19 (https://stockfishchess.org, by the Stockfish developers - see AUTHORS)
with 55 search parameters retuned by SPSA and baked in as constants.

src-native/          the Kaifish source exactly as compiled natively: `cd src-native/src && make -j build ARCH=x86-64-avx2`
src-wasm-kaifish/    the Kaifish tree compiled to WebAssembly (src-native + stockfish-web patch + glue + KF_ST edits)
src-wasm-stockfish19/ plain Stockfish 19 with the same web changes (the "sf19" engines on the page)
web/                 prep.py (copy, bake, patch), build_wasm.py (Emscripten, identical flags for both engines),
                     build_native.py, test_engines.py, glue/ (UCI over postMessage), patches/ (lichess stockfish-web, GPL-3)
tools/               the tuning tools: make_tunable.py, bake.py, kaifish_run.py (SPSA + match runner), params_default.json
tuned-params.json    the 55 tuned values that are baked into src-native and src-wasm-kaifish
The NNUE net nn-1a298aa575a0.nnue is not included (98.5 MB): it is the Stockfish 19 default net, from
https://tests.stockfishchess.org/api/nn/nn-1a298aa575a0.nnue (also served with this page in two parts).
